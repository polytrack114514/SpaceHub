const { chromium } = require('playwright');

(async () => {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage();

  console.log('Navigating to Supabase SQL Editor...');
  await page.goto('https://supabase.com/dashboard/project/tktfrrvaqwbtdhiqwnna/sql/9f377e74-ac72-4ae4-adb4-ccf3bd7ade08', {
    waitUntil: 'networkidle',
    timeout: 60000
  });

  // Wait for page to load
  await page.waitForTimeout(5000);

  // Take a screenshot to see what's on the page
  await page.screenshot({ path: '/workspace/supabase_before.png', fullPage: true });
  console.log('Screenshot saved before interaction');

  // Get page content to understand structure
  const title = await page.title();
  console.log(`Page title: ${title}`);

  // Check if we're on a login page
  const url = page.url();
  console.log(`Current URL: ${url}`);

  // Try to find the SQL input area - Supabase SQL editor typically has a codemirror or similar
  const possibleEditors = await page.evaluate(() => {
    // Look for CodeMirror editors
    const cmElements = document.querySelectorAll('.CodeMirror, [class*="CodeMirror"]');
    // Look for textarea elements that might be the SQL editor
    const textareas = document.querySelectorAll('textarea');
    // Look for elements with sql-related classes
    const sqlElements = document.querySelectorAll('[class*="sql"], [class*="query"], [class*="editor"]');

    return {
      codemirrorCount: cmElements.length,
      textareaCount: textareas.length,
      sqlElementCount: sqlElements.length,
      textareas: Array.from(textareas).map((t, i) => ({
        index: i,
        classes: t.className,
        id: t.id,
        placeholder: t.placeholder,
        visible: t.offsetParent !== null
      })),
      firstFewButtons: Array.from(document.querySelectorAll('button')).slice(0, 10).map(b => ({
        text: b.textContent?.trim()?.substring(0, 50),
        classes: b.className?.substring(0, 100),
        disabled: b.disabled
      }))
    };
  });

  console.log(JSON.stringify(possibleEditors, null, 2));

  await browser.close();
})();
